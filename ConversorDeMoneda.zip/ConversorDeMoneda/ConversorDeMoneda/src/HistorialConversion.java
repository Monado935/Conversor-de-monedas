public record HistorialConversion(String base_code,
                                  String target_code,
                                  Double montoOriginal,
                                  String fechaDeConversion,
                                  Double conversion_rate,
                                  Double conversion_result) {
}
